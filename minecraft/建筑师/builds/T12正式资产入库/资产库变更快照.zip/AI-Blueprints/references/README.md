# 当前参考库增量

2026-09-12：已追加 **REF-0123 · 江户后期京都呉服商町家院落**，现有 123 个稳定 REF。T12 最终实存、Owner 批准、26.2 原生互通验证与完整 metadata 见 [REF-0123](derived/REF-0123/README.md)。资产状态 REFERENCE_ONLY 表示未获任何新场地施工授权。

下文保留原 V6B 122 项历史批次报告，其统计不代表新增批次。新增条目走既有 catalog / V2 / index；不要重跑固定 122 项历史任务覆盖增量。

---

# Minecraft AI Build V6B — REFERENCE LIBRARY INGESTED

122/122 张已扫描和归档；122 个稳定 REF ID；原文件修改 0；Minecraft world write 0。所有条目均为 REFERENCE_ONLY，未晋升、未实装，没有 Gallery 或 V6C。

## 技术状态

| 主状态 | 数量 |
|---|---:|
| READY | 0 |
| READY_WITH_WARNINGS | 0 |
| OLD_DATAVERSION | 70 |
| UNRESOLVED_BLOCKS | 52 |
| PARSE_FAILED | 0 |
| POSSIBLE_CORRUPT | 0 |

成功解析：122。主状态互斥；全部 122 都有 OLD_DATAVERSION 风险，其中 52 同时含当前快照不存在的旧 vanilla identifier（minecraft:grass / minecraft:chain），所以主状态归入 UNRESOLVED_BLOCKS。未自动迁移、替换或删除这些块。Modded schematics 为 0。

## 分类统计

primary_use：landmark 25；residential 23；landscape 14；military 13；religious 10；industrial 8；commercial 8；transport 7；unknown 6；civic 4；agricultural 3；mixed_use 1。

style Top 10：unknown 51；medieval 37；rustic 21；cottage 20；fantasy 15；east_asian 15；japanese 8；chinese 7；fortified 5；european 4。unknown 也如实计入，不用文件名填满风格标签。

scale：large 43；medium 38；small 23；tiny 10；monumental 8。

最常见用途：house 21；tower 13；tree 9；castle 7；palace 6；tavern 5；church 5；shop 4；airship 4；gatehouse 3。

review queue：122。全部包含技术风险需要复核；条目 reasons 进一步区分低置信度、unknown、冲突及功能问题。含 block entities：89；含 entities：46；multi-region 原件：0，另有双 Region 负向夹具验证。

## 证据与性能

固定版本最终完整批次：35.229 秒，平均 288.76 ms/张；不含前期规则修订和抽样阅读时间。最大/最慢：REF-0113 象牙城堡，1,156,099 个非空气块、8,836,800 格包络，6478.77 ms。总归档约 39,816,064 格，air 显式保存。

49 张容量允许的归档与冻结 V6A 的完整坐标/state、origin/dimensions、typed 辅助 NBT 完全一致。13 张分层样本全数据复核 PASS，含最大原件；8 项契约测试 PASS。4 张低置信度样本使用静态体素图复核，未打开任何 V5 Preview。再次扫描按 hash 跳过 122，原 ID 不变。

122 个原文件 SHA256 全部未变，76 个 V3/V5/V6A 冻结文件 hash 一致。四层依赖检查 PASS，未跨模块引用内部层。独立归档 reader 仅突破只读容量限制，继续使用 Canonical schema_version=1，未降低实装关卡。

## 来源与入口

122 个来源网页从本地 Zone.Identifier 恢复；46 个作者从 NBT 恢复。未读取网页；缺失许可证/下载日期为 unknown。原件留原地，不复制或移动。

- [Catalog JSON](/D:/Games/Minecraft/AI工程/AI-Blueprints/references/catalog/catalog.json)
- [Catalog CSV](/D:/Games/Minecraft/AI工程/AI-Blueprints/references/catalog/catalog.csv)
- [永久 ID 映射](/D:/Games/Minecraft/AI工程/AI-Blueprints/references/catalog/reference-id-map.json)
- [索引](/D:/Games/Minecraft/AI工程/AI-Blueprints/references/indexes/inverted-index.json)
- [规则](/D:/Games/Minecraft/AI工程/AI-Blueprints/references/catalog/classification-rules.md)
- [13 张抽样复核](/D:/Games/Minecraft/AI工程/AI-Test/Reference-Library-V6B/evidence/sample-review.md)
- [复核队列](/D:/Games/Minecraft/AI工程/AI-Blueprints/references/catalog/review-queue.json)
- [CLI 与公开入口](/D:/Games/Minecraft/AI工程/AI-Blueprints/参考入库/README.md)

## 使用边界

分类为带置信度的检索候选，不是 Owner 最终判断。实体虽完整保留，V3 不支持其写入；旧版 DataFixer native migration 未自动完成。73 张超出 V5 预览容量，属于受限预览而非损坏；特殊 renderer 仍沿用 V5 fallback。未来使用 REF 必须另行 Promotion/Review，本轮未实现 Promotion。
